﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryManagment.controllers
{
    internal class Member : MyController<tables.Member>
    {
        internal Member() :base()
        {
            
        } 
    }
}
