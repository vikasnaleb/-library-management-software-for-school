﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryManagment.controllers
{
    internal class Circulation : MyController<tables.Circulation>
    {
        internal Circulation() :base()
        {
            
        } 
    }
}
